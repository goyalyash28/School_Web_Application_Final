package com.controllers;

import com.dtos.*;
import com.services.TeacherService;
import com.response.GeneralResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    @PostMapping("/teacher")
    public GeneralResponse addTeacher(@RequestBody TeacherDto teacherDto) {
        GeneralResponse response = new GeneralResponse();
        try {
            return teacherService.addTeacher(teacherDto);
        } catch (Exception e) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry something went wrong!");
            return response;
        }
    }

    @GetMapping("/teachers")
    public GeneralResponse getAllTeachers() {
        GeneralResponse response = new GeneralResponse();
        try {
            response.setData(teacherService.getAllTeachers());
            response.setStatus(HttpStatus.OK);
            return response;
        } catch (Exception ex) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something Wrong Happened.");
            return response;
        }
    }

    @GetMapping("/teachersForHome")
    public GeneralResponse getAllTeachersForHome() {
        GeneralResponse response = new GeneralResponse();
        try {
            response.setData(teacherService.getAllTeachersForHome());
            response.setStatus(HttpStatus.OK);
            return response;
        } catch (Exception ex) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something Wrong Happened.");
            return response;
        }
    }

    @GetMapping("/teacher/{teacherId}")
    public GeneralResponse getTeacherById(@PathVariable Long teacherId) {
        GeneralResponse response = new GeneralResponse();
        try {
            response.setData(teacherService.getTeacherById(teacherId));
            response.setStatus(HttpStatus.OK);
            return response;
        } catch (Exception ex) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something Wrong Happened.");
            return response;
        }
    }

    @PutMapping("/teacher/{teacherId}")
    public GeneralResponse updateTeacher(@PathVariable Long teacherId, @RequestBody TeacherDto teacherDto) {
        GeneralResponse response = new GeneralResponse();
        try {
            return (teacherService.updateTeacher(teacherId, teacherDto));
        } catch (Exception e) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something went wrong!");
            return response;
        }
    }

}
