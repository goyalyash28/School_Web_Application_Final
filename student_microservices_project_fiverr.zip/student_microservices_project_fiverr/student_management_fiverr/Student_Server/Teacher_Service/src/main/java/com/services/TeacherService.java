package com.services;


import com.dtos.*;
import com.response.GeneralResponse;

import java.util.List;

public interface TeacherService {

    GeneralResponse addTeacher(TeacherDto teacherDto);

    List<TeacherDto> getAllTeachers();

    List<TeacherDto> getAllTeachersForHome();

    SingleTeacherDto getTeacherById(Long teacherId);

    GeneralResponse updateTeacher(Long teacherId, TeacherDto teacherDto);

}
