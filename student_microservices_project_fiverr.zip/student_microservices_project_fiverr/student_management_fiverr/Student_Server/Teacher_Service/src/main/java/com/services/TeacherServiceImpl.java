package com.services;

import com.dtos.*;
import com.entities.*;
import com.enums.UserRole;
import com.repos.*;
import com.response.GeneralResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private TeacherRepo teacherRepo;

    @Override
    public GeneralResponse addTeacher(TeacherDto teacherDto) {
        GeneralResponse response = new GeneralResponse();
        Teacher teacher = new Teacher();
        teacher.setName(teacherDto.getName());
        teacher.setGender(teacherDto.getGender());
        teacher.setQualification(teacherDto.getQualification());
        teacherRepo.save(teacher);
        response.setMessage("Teacher added successfully!");
        response.setStatus(HttpStatus.CREATED);
        return response;
    }

    @Override
    public List<TeacherDto> getAllTeachers() {
        return teacherRepo.findAll().stream().map(Teacher::getTeacherDto).collect(Collectors.toList());
    }

    @Override
    public List<TeacherDto> getAllTeachersForHome() {
        return teacherRepo.findAll().stream().map(Teacher::getTeacherDto).collect(Collectors.toList());
    }

    @Override
    public SingleTeacherDto getTeacherById(Long teacherId) {
        SingleTeacherDto singleTeacherDto = new SingleTeacherDto();
        Optional<Teacher> optionalTeacher = teacherRepo.findById(teacherId);
        if (optionalTeacher.isPresent()) {
            singleTeacherDto.setTeacherDto(optionalTeacher.get().getTeacherDto());
        }
        return singleTeacherDto;
    }

    @Override
    public GeneralResponse updateTeacher(Long teacherId, TeacherDto teacherDto) {
        GeneralResponse response = new GeneralResponse();
        Optional<Teacher> optionalTeacher = teacherRepo.findById(teacherId);
        if (optionalTeacher.isPresent()) {
            Teacher teacher = optionalTeacher.get();
            teacher.setName(teacherDto.getName());
            teacher.setGender(teacherDto.getGender());
            teacher.setQualification(teacherDto.getQualification());
            teacherRepo.save(teacher);
            response.setMessage("Teacher updated Successfully");
            response.setStatus(HttpStatus.OK);
        } else {
            response.setStatus(HttpStatus.NOT_ACCEPTABLE);
            response.setMessage("Teacher not found!");
        }
        return response;
    }

}




