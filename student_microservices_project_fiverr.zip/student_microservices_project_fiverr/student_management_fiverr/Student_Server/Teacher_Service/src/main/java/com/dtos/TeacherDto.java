package com.dtos;

import lombok.Data;

@Data
public class TeacherDto {

    private Long id;

    private String name;

    private String gender;

    private String qualification;

}
