package com.dtos;

import lombok.Data;

@Data
public class SingleTeacherDto {

    private TeacherDto teacherDto;


}
