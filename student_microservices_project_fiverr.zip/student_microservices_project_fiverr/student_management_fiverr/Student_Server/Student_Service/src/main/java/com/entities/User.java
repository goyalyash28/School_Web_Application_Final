package com.entities;


import com.dtos.StudentDto;
import com.enums.UserRole;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "users")
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String email;

    private String password;

    private String name;

    private String fatherName;

    private String motherName;

    private String studentClass;

    private Date dateOfBirth;

    private String gender;

    private UserRole role;

    public StudentDto getStudentDto() {
        StudentDto studentDto = new StudentDto();
        studentDto.setId(id);
        studentDto.setName(name);
        studentDto.setEmail(email);
        studentDto.setFatherName(fatherName);
        studentDto.setMotherName(motherName);
        studentDto.setStudentClass(studentClass);
        studentDto.setDateOfBirth(dateOfBirth);
        studentDto.setGender(gender);
        studentDto.setRole(role);
        studentDto.setEmail(email);
        studentDto.setEmail(email);
        return studentDto;
    }

}
