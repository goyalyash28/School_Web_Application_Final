package com.services;


import com.dtos.*;
import com.response.GeneralResponse;

import java.util.List;

public interface StudentService {


    GeneralResponse addStudent(StudentDto studentDto);


    List<StudentDto> getAllStudents();

    SingleStudentDto getStudentById(Long studentId);

    GeneralResponse updateStudent(Long studentId, StudentDto studentDto);

    GeneralResponse addFee(FeeDto feeDto);

    GeneralResponse messageToTeacher(MessageDto messageDto);

    List<MessageDto> getAlLMessagesByUserId(Long userId);

    SingleStudentDto getStudentByUserId(Long userId);

    GeneralResponse applyLeave(StudentLeaveDto studentLeaveDto);
}
