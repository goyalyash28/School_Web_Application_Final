package com.controllers;

import com.dtos.*;
import com.services.StudentService;
import com.response.GeneralResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/student")
    public GeneralResponse addStudent(@RequestBody StudentDto studentDto) {
        GeneralResponse response = new GeneralResponse();
        try {
            return studentService.addStudent(studentDto);
        } catch (Exception e) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry something went wrong!");
            return response;
        }
    }

    @GetMapping("/students")
    public GeneralResponse getAllStudents() {
        GeneralResponse response = new GeneralResponse();
        try {
            response.setData(studentService.getAllStudents());
            response.setStatus(HttpStatus.OK);
            return response;
        } catch (Exception ex) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something Wrong Happened.");
            return response;
        }
    }

    @GetMapping("/student/{studentId}")
    public GeneralResponse getStudentById(@PathVariable Long studentId) {
        GeneralResponse response = new GeneralResponse();
        try {
            response.setData(studentService.getStudentById(studentId));
            response.setStatus(HttpStatus.OK);
            return response;
        } catch (Exception ex) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something Wrong Happened.");
            return response;
        }
    }
    @PutMapping("/student/{studentId}")
    public GeneralResponse updateStudent(@PathVariable Long studentId, @RequestBody StudentDto studentDto) {
        GeneralResponse response = new GeneralResponse();
        try {
            return (studentService.updateStudent(studentId, studentDto));
        } catch (Exception e) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something went wrong!");
            return response;
        }
    }

    @PostMapping("/fee")
    public GeneralResponse addFee(@RequestBody FeeDto feeDto) {
        GeneralResponse response = new GeneralResponse();
        try {
            return studentService.addFee(feeDto);
        } catch (Exception e) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry something went wrong!");
            return response;
        }
    }

    @PostMapping("/message")
    public GeneralResponse messageToTeacher(@RequestBody MessageDto messageDto) {
        GeneralResponse response = new GeneralResponse();
        try {
            return studentService.messageToTeacher(messageDto);
        } catch (Exception e) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry something went wrong!");
            return response;
        }
    }

    @GetMapping("/messages/{userId}")
    public GeneralResponse getAlLMessagesByUserId(@PathVariable Long userId) {
        GeneralResponse response = new GeneralResponse();
        try {
            response.setData(studentService.getAlLMessagesByUserId(userId));
            response.setStatus(HttpStatus.OK);
            return response;
        } catch (Exception ex) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something Wrong Happened.");
            return response;
        }
    }

    @GetMapping("/studentByUserId/{userId}")
    public GeneralResponse getStudentByUserId(@PathVariable Long userId) {
        GeneralResponse response = new GeneralResponse();
        try {
            response.setData(studentService.getStudentByUserId(userId));
            response.setStatus(HttpStatus.OK);
            return response;
        } catch (Exception ex) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry Something Wrong Happened.");
            return response;
        }
    }

    @PostMapping("/leave")
    public GeneralResponse applyLeave(@RequestBody StudentLeaveDto studentLeaveDto) {
        GeneralResponse response = new GeneralResponse();
        try {
            return studentService.applyLeave(studentLeaveDto);
        } catch (Exception e) {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setMessage("Sorry something went wrong!");
            return response;
        }
    }

}
