package com.dtos;

import lombok.Data;

@Data
public class SingleStudentDto {

    private StudentDto studentDto;

}
