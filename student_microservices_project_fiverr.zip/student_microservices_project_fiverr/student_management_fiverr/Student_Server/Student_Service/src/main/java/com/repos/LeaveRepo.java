package com.repos;

import com.entities.StudentLeave;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeaveRepo extends JpaRepository<StudentLeave,Long> {
}
