package com.dtos;

import com.enums.UserRole;
import lombok.Data;

import java.util.Date;

@Data
public class StudentDto {

    private Long id;

    private String email;

    private String name;

    private String password;

    private String fatherName;

    private String motherName;

    private String studentClass;

    private Date dateOfBirth;

    private String gender;

    private UserRole role;

}
