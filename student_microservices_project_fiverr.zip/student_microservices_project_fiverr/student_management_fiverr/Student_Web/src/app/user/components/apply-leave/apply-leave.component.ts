import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { StudentService } from '../../user-services/student.service';

@Component({
  selector: 'app-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.scss']
})
export class ApplyLeaveComponent implements OnInit {

  dateFormat = 'yyyy-MM-dd';
  isSpinning = false;
  size: NzButtonSize = 'large';
  validateForm!: FormGroup;

  constructor(private fb: FormBuilder,
    private studentService: StudentService,
    private notification: NzNotificationService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      subject: [null, [Validators.required]],
      body: [null, [Validators.required]],
    });
  }

  applyLeave(data: any) {
    console.log(this.validateForm.value);
    console.log(data);
    this.isSpinning = true;
    this.studentService.applyLeave(data).subscribe((res) => {
      console.log(res);
      this.isSpinning = false;
      if (res.status == "CREATED") {
        this.notification
          .success(
            'SUCCESS',
            `Leave Applied successfully!`,
            { nzDuration: 5000 }
          );
        this.router.navigateByUrl('user/dashboard');
      } else {
        this.notification
          .error(
            'ERROR',
            `${res.message}`,
            { nzDuration: 5000 }
          )
      }
    }, error => {
      console.log("errorr", error);
      if (error.status == 406) {
        this.notification
          .error(
            'ERROR',
            `${error.error}`,
            { nzDuration: 5000 }
          )
      }
      this.isSpinning = false;
    })
  }

}
