import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { StudentService } from '../../user-services/student.service';

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.scss']
})
export class UpdateStudentComponent implements OnInit {

  CLASS: string[] = [
    "Play", "Nursery", "Prep", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th"
  ]

  GENDER: string[] = [
    "Male", "Female"
  ]

  dateFormat = 'yyyy-MM-dd';
  isSpinning = false;
  size: NzButtonSize = 'large';
  validateForm!: FormGroup;
  studentId: any = this.activatedroute.snapshot.params['studentId'];
  student: any


  constructor(private fb: FormBuilder,
    private notification: NzNotificationService,
    private router: Router,
    private studentService: StudentService,
    private activatedroute: ActivatedRoute,) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      email: [null, [Validators.required]],
      name: [null, [Validators.required]],
      fatherName: [null, [Validators.required]],
      motherName: [null, [Validators.required]],
      studentClass: [null, [Validators.required]],
      dateOfBirth: [null, [Validators.required]],
      gender: [null, [Validators.required]],
    });
    this.getStudentByStudentId();
  }

  getStudentByStudentId() {
    this.studentService.getStudentByStudentId(this.studentId).subscribe((res) => {
      console.log(res);
      const student = res.data.studentDto;
      this.validateForm.patchValue(student);
    })
  }

  updateStudent(data: any) {
    console.log(this.validateForm.value);
    console.log(data);
    this.isSpinning = true;
    this.studentService.updateStudent(this.studentId, data).subscribe((res) => {
      console.log(res);
      this.isSpinning = false;
      if (res.status == "OK") {
        this.notification
          .success(
            'SUCCESS',
            `Student updated successfully!`,
            { nzDuration: 5000 }
          );
        this.router.navigateByUrl('user/dashboard');
      } else {
        this.notification
          .error(
            'ERROR',
            `${res.message}`,
            { nzDuration: 5000 }
          )
      }
    }, error => {
      console.log("errorr", error);
      if (error.status == 406) {
        this.notification
          .error(
            'ERROR',
            `${error.error}`,
            { nzDuration: 5000 }
          )
      }
      this.isSpinning = false;
    })
  }

}
