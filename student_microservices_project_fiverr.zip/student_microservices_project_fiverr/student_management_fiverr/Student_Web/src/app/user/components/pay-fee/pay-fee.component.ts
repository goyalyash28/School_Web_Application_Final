import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { UserStorageService } from 'src/app/services/storage/user-storage.service';
import { StudentService } from '../../user-services/student.service';

@Component({
  selector: 'app-pay-fee',
  templateUrl: './pay-fee.component.html',
  styleUrls: ['./pay-fee.component.scss']
})
export class PayFeeComponent implements OnInit {

  serialNumber: any = this.activatedroute.snapshot.params['serialNumber'];
  dateFormat = 'yyyy-MM-dd';
  isSpinning = false;
  size: NzButtonSize = 'large';
  validateForm!: FormGroup;

  constructor(private fb: FormBuilder,
    private studentService: StudentService,
    private notification: NzNotificationService,
    private activatedroute: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      amount: [null, [Validators.required]],
      month: [null, [Validators.required]],
      year: [null, [Validators.required]],
      givenBy: [null, [Validators.required]],
      description: [null],
    });
  }

  addFee(data: any) {
    console.log(this.validateForm.value);
    data.serialNumber = this.serialNumber;
    data.userId = UserStorageService.getUserId();
    this.isSpinning = true;
    this.studentService.addFee(this.serialNumber, data).subscribe((res) => {
      console.log(res);
      this.isSpinning = false;
      if (res.status == "CREATED") {
        this.notification
          .success(
            'SUCCESS',
            `Fee added successfully!`,
            { nzDuration: 5000 }
          );
        this.router.navigateByUrl('user/dashboard');
      } else {
        this.notification
          .error(
            'ERROR',
            `${res.message}`,
            { nzDuration: 5000 }
          )
      }
    }, error => {
      console.log("errorr", error);
      if (error.status == 406) {
        this.notification
          .error(
            'ERROR',
            `${error.error}`,
            { nzDuration: 5000 }
          )
      }
      this.isSpinning = false;
    })
  }

}
