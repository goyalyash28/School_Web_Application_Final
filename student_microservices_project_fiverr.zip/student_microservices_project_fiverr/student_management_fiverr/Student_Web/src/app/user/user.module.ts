import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserComponent } from './user.component';
import { DemoNgZorroAntdModule } from '../DemoNgZorroAntdModule';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UpdateStudentComponent } from './components/update-student/update-student.component';
import { PayFeeComponent } from './components/pay-fee/pay-fee.component';
import { SendMessageComponent } from './components/send-message/send-message.component';
import { MessageComponent } from './components/message/message.component';
import { MyMessagesComponent } from './components/my-messages/my-messages.component';
import { ApplyLeaveComponent } from './components/apply-leave/apply-leave.component';


@NgModule({
  declarations: [
    UserComponent,
    DashboardComponent,
    UpdateStudentComponent,
    PayFeeComponent,
    SendMessageComponent,
    MessageComponent,
    MyMessagesComponent,
    ApplyLeaveComponent,
],
  imports: [
    CommonModule,
    FormsModule,
    UserRoutingModule,
    DemoNgZorroAntdModule,
    ReactiveFormsModule
  ]
})
export class UserModule { }
