import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuard } from '../guards/authAdmin/admin.guard';
import { AddStudentComponent } from './components/add-student/add-student.component';
import { AddTeacherComponent } from './components/add-teacher/add-teacher.component';
import { AllTeachersComponent } from './components/all-teachers/all-teachers.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UpdateStudentComponent } from './components/update-student/update-student.component';
import { UpdateTeacherComponent } from './components/update-teacher/update-teacher.component';

const routes: Routes = [

  { path: 'dashboard', component: DashboardComponent, canActivate: [AdminGuard] },
  { path: 'student', component: AddStudentComponent, canActivate: [AdminGuard] },
  { path: 'student/:serialNumber', component: UpdateStudentComponent, canActivate: [AdminGuard] },
  { path: 'teacher', component: AddTeacherComponent, canActivate: [AdminGuard] },
  { path: 'teachers', component: AllTeachersComponent, canActivate: [AdminGuard] },
  { path: 'teacher/:teacherId', component: UpdateTeacherComponent, canActivate: [AdminGuard] },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
