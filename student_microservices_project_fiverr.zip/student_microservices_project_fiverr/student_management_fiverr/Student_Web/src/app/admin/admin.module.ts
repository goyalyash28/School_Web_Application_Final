import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { DemoNgZorroAntdModule } from '../DemoNgZorroAntdModule';
import { ReactiveFormsModule } from '@angular/forms';
import { AddStudentComponent } from './components/add-student/add-student.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UpdateStudentComponent } from './components/update-student/update-student.component';
import { AddTeacherComponent } from './components/add-teacher/add-teacher.component';
import { AllTeachersComponent } from './components/all-teachers/all-teachers.component';
import { UpdateTeacherComponent } from './components/update-teacher/update-teacher.component';



@NgModule({
  declarations: [
    AdminComponent,
    AddStudentComponent,
    DashboardComponent,
    UpdateStudentComponent,
    AddTeacherComponent,
    AllTeachersComponent,
    UpdateTeacherComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    DemoNgZorroAntdModule,
    ReactiveFormsModule
  ]
})
export class AdminModule { }
