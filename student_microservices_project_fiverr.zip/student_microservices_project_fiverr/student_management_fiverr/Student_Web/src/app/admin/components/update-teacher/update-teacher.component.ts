import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { AdminService } from '../../admin-services/admin.service';

@Component({
  selector: 'app-update-teacher',
  templateUrl: './update-teacher.component.html',
  styleUrls: ['./update-teacher.component.scss']
})
export class UpdateTeacherComponent implements OnInit {

  GENDER: string[] = [
    "Male", "Female"
  ]

  dateFormat = 'yyyy-MM-dd';
  isSpinning = false;
  size: NzButtonSize = 'large';
  validateForm!: FormGroup;
  teacherId: any = this.activatedroute.snapshot.params['teacherId'];
  teacher: any


  constructor(private fb: FormBuilder,
    private notification: NzNotificationService,
    private router: Router,
    private adminService: AdminService,
    private activatedroute: ActivatedRoute,) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      name: [null, [Validators.required]],
      qualification: [null, [Validators.required]],
      gender: [null, [Validators.required]],
    });
    this.getTeacherById();
  }

  getTeacherById() {
    this.adminService.getTeacherById(this.teacherId).subscribe((res) => {
      console.log(res);
      const teacher = res.data.teacherDto;
      this.validateForm.patchValue(teacher);
    })
  }

  updateStudent(data: any) {
    console.log(this.validateForm.value);
    console.log(data);
    this.isSpinning = true;
    this.adminService.updateTeacher(this.teacherId, data).subscribe((res) => {
      console.log(res);
      this.isSpinning = false;
      if (res.status == "OK") {
        this.notification
          .success(
            'SUCCESS',
            `Teacher updated successfully!`,
            { nzDuration: 5000 }
          );
        this.router.navigateByUrl('admin/teachers');
      } else {
        this.notification
          .error(
            'ERROR',
            `${res.message}`,
            { nzDuration: 5000 }
          )
      }
    }, error => {
      console.log("errorr", error);
      if (error.status == 406) {
        this.notification
          .error(
            'ERROR',
            `${error.error}`,
            { nzDuration: 5000 }
          )
      }
      this.isSpinning = false;
    })
  }

}
